// var greeter = function(name){
//     console.log('Hello, ' + name);
// }

// greeter('John Smith');

let greeter = (firstName, lastName) => {
    console.log(`Hello, ${firstName} ${lastName}`);
}

greeter('John', 'Smith');
